# Reel Pretty Blooms Website

This is a simple starter website for Reel Pretty Blooms.

## How to use
- Open index.html in your browser
- Customize text, images, and contact info
- Upload to GitHub Pages for free hosting

## Next step (recommended)
Connect this repo to GitHub Pages for live website hosting.
